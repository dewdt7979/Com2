#include<stdio.h>
int main()
{
	int lab[4][5],i,col;
	FILE *inf;
	inf = fopen("Lab.txt","r");
	for(i=0;i<4;i++)
	{
		for(col=0;col<5;col++)
		{
			fscanf(inf,"%d",&lab[i][col]);
		}
	}
	for(i=0;i<4;i++)
	{
		for(col=0;col<5;col++)
		{
			printf("%d \t ",lab[i][col]);
			printf("\t");
		}
		printf("\n");
	}
	return 0;
}
