#include<stdio.h>
#include<stdlib.h>
typedef struct node{
	int data;
	struct node *left,*right;
}treenode;

void insertBST(treenode **root,treenode *newnode)
{
	treenode *run,*prev;
	if(*root == NULL) //tree is empty.
	{
		*root = newnode; //root target newnode.
	}
	else //tree isn't empty
	{
		run = *root;	
		while(run!=NULL)
		{
			prev = run;
			if(newnode->data > run->data)
			{
				run = run->right;
			}
			else if(newnode->data < run->data)
			{
				run = run->left; 
			}
			 //End loop,find prev. and run is NULL.
		
		}
		//connect newnode into BST.
		if(newnode->data > prev->data)
		{
				prev->right = newnode;
		}
		else if(newnode->data < prev->data)
		{
				prev->left = newnode;
		}
	}	
}
treenode* createtree(treenode *root)
{
	FILE *inf;
	treenode *newnode;
	int newdata;
	inf = fopen("tree.txt","r");
	fscanf(inf,"%d",&newdata);
	while(!feof(inf))
	{
		newnode = (treenode*)malloc(sizeof(treenode));
		newnode->data = newdata;
		newnode->left = NULL; //set left is empty
		newnode->right = NULL; //set right is empty
		//call insertBST here
		insertBST(&root,newnode);
		fscanf(inf,"%d",&newdata); 
	}
	fclose(inf);
	return(root);
}
void Inorder(treenode *root)
{
	if(root != NULL)
	{	
		Inorder(root->left);
		printf("Node = %d\n",root->data);
		Inorder(root->right);
	} //Inorder
}
void Preorder(treenode *root)
{
	if(root != NULL)
	{		
		printf("Node = %d\n",root->data);
		Inorder(root->left);
		Inorder(root->right);
	} //Preorder.
}
int main()
{
    treenode *root=NULL;
    root = createtree(root);
    Inorder(root);
    //Preorder(root);
	return 0;
}
